﻿using System;

namespace Tiny.RestClient.Tests.Models
{
    public class Request
    {
        public int Id { get; set; }
        public string Data { get; set; }
    }
}
