Tiny.RestClient is a community effort. Code contributions are always welcomed.

Before to contribute juste follow these guidelines:

* Start by creating an issue and describing your proposed fix/enhancement.
* Fork the project and make your changes in the develop branch, your pull request must be on develop branch.
* Write tests to cover all new/changed functionality. Your tests should fail without your changes and pass with them.
* Add commments to any new public methods/properties/ect.
* Check you have don't add any warning in the project
